"""CampusRooms demo server built with Python's standard library."""
from datetime import date, datetime
from http import HTTPStatus
from pathlib import Path
from urllib.parse import parse_qs
from contextlib import contextmanager
import json
import os
import re
import sqlite3
from wsgiref.simple_server import make_server

BASE = Path(__file__).resolve().parent
DB_PATH = Path(os.environ.get('ROOM_BOOKING_DB', BASE / 'instance' / 'rooms.db'))


@contextmanager
def connect():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute('PRAGMA foreign_keys = ON')
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db():
    with connect() as db:
        db.executescript('''
        CREATE TABLE IF NOT EXISTS rooms (
            id INTEGER PRIMARY KEY, code TEXT UNIQUE NOT NULL,
            capacity INTEGER NOT NULL CHECK(capacity > 0),
            projector INTEGER NOT NULL DEFAULT 0,
            computers INTEGER NOT NULL DEFAULT 0,
            whiteboard INTEGER NOT NULL DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS bookings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            room_id INTEGER NOT NULL REFERENCES rooms(id),
            student TEXT NOT NULL, booking_date TEXT NOT NULL,
            start_time TEXT NOT NULL, end_time TEXT NOT NULL,
            purpose TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'active',
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            CHECK(start_time < end_time)
        );
        CREATE INDEX IF NOT EXISTS idx_booking_date_room
          ON bookings(booking_date, room_id, status);
        ''')
        rooms = [
            ('C1', 12, 1, 0, 1), ('C2', 24, 1, 1, 1),
            ('C3', 18, 0, 1, 1), ('101', 36, 1, 1, 0),
            ('150', 8, 0, 0, 1), ('200', 28, 1, 0, 1),
            ('250', 16, 0, 1, 0), ('300', 42, 1, 1, 1),
        ]
        old_codes = ['A101', 'A204', 'B110', 'B215', 'C020', 'C112', 'D305', 'D410']
        existing = {row['code'] for row in db.execute('SELECT code FROM rooms')}
        if not existing:
            db.executemany('INSERT INTO rooms(code,capacity,projector,computers,whiteboard) VALUES(?,?,?,?,?)', rooms)
            today = date.today().isoformat()
            samples = [
                (2, 'Jamie Lee', today, '09:00', '10:30', 'Group study session'),
                (4, 'Taylor Reed', today, '13:00', '14:00', 'Project meeting'),
                (1, 'Stephen Curry', today, '15:00', '16:00', 'Exam preparation'),
                (6, 'Morgan Blake', today, '11:00', '12:00', 'Design workshop'),
            ]
            db.executemany('INSERT INTO bookings(room_id,student,booking_date,start_time,end_time,purpose) VALUES(?,?,?,?,?,?)', samples)
        elif existing == set(old_codes):
            for old_code, room in zip(old_codes, rooms):
                db.execute('UPDATE rooms SET code=? WHERE code=?', (room[0], old_code))
        db.execute("UPDATE bookings SET student='Stephen Curry' WHERE student='Alex Morgan'")


def booking_dict(row):
    result = dict(row)
    result['room'] = result.pop('code')
    result['is_owner'] = result['student'] == 'Stephen Curry'
    return result


def response(start_response, status, body, content_type='application/json; charset=utf-8'):
    data = body if isinstance(body, bytes) else (json.dumps(body, ensure_ascii=False).encode('utf-8') if content_type.startswith('application/json') else body.encode('utf-8'))
    start_response(f'{status} {HTTPStatus(status).phrase}', [
        ('Content-Type', content_type), ('Content-Length', str(len(data))),
        ('X-Content-Type-Options', 'nosniff'), ('X-Frame-Options', 'DENY'),
        ('Referrer-Policy', 'strict-origin-when-cross-origin'),
        ('Content-Security-Policy', "default-src 'self'; style-src 'self'; script-src 'self'; img-src 'self' data:; connect-src 'self'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'"),
    ])
    return [data]


def application(environ, start_response):
    path, method = environ.get('PATH_INFO', '/'), environ.get('REQUEST_METHOD', 'GET')
    original_start_response = start_response
    def secured_start_response(status, headers, exc_info=None):
        headers = list(headers)
        if environ.get('HTTP_X_FORWARDED_PROTO', '').lower() == 'https':
            headers.append(('Strict-Transport-Security', 'max-age=31536000; includeSubDomains'))
        return original_start_response(status, headers, exc_info)
    start_response = secured_start_response
    if os.environ.get('FORCE_HTTPS') == '1' and environ.get('HTTP_X_FORWARDED_PROTO', '').lower() == 'http':
        target = 'https://' + environ.get('HTTP_HOST', '') + path
        if environ.get('QUERY_STRING'):
            target += '?' + environ['QUERY_STRING']
        start_response('308 Permanent Redirect', [('Location', target), ('Content-Length', '0')])
        return [b'']
    query = parse_qs(environ.get('QUERY_STRING', ''), keep_blank_values=True)
    value = lambda key, default='': query.get(key, [default])[0]
    if method == 'GET' and path == '/':
        html = (BASE / 'templates' / 'index.html').read_text(encoding='utf-8')
        html = html.replace("{{ url_for('static', filename='styles.css') }}", '/static/styles.css')
        html = html.replace("{{ url_for('static', filename='app.js') }}", '/static/app.js')
        return response(start_response, 200, html, 'text/html; charset=utf-8')
    if method == 'GET' and path == '/robots.txt':
        body = 'User-agent: *\nAllow: /\nSitemap: https://find-your-class-dias.onrender.com/sitemap.xml\n'
        return response(start_response, 200, body, 'text/plain; charset=utf-8')
    if method == 'GET' and path == '/sitemap.xml':
        body = ('<?xml version="1.0" encoding="UTF-8"?>'
                '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'
                '<url><loc>https://find-your-class-dias.onrender.com/</loc></url>'
                '</urlset>')
        return response(start_response, 200, body, 'application/xml; charset=utf-8')
    if method == 'GET' and path in ('/static/styles.css', '/static/custom.css', '/static/app.js'):
        file_name = path.rsplit('/', 1)[-1]
        mime = 'text/css; charset=utf-8' if file_name.endswith('.css') else 'text/javascript; charset=utf-8'
        return response(start_response, 200, (BASE / 'static' / file_name).read_bytes(), mime)
    if method == 'GET' and path == '/api/health':
        return response(start_response, 200, {'status': 'ok'})
    if method == 'GET' and path == '/api/rooms':
        try:
            capacity = max(0, min(int(value('capacity', '0') or 0), 1000))
        except ValueError:
            return response(start_response, 400, {'error': 'Capacity must be a number.'})
        day = value('date') or date.today().isoformat()
        start, end = value('start'), value('end')
        if start and end:
            try:
                if datetime.strptime(start, '%H:%M') >= datetime.strptime(end, '%H:%M'):
                    raise ValueError
            except ValueError:
                return response(start_response, 400, {'error': 'Enter a valid time range.'})
        equipment = [key for key in ('projector', 'computers', 'whiteboard') if value(key) == 'true']
        slots = [('08:00','09:00'),('09:00','10:00'),('10:00','11:00'),('11:00','12:00'),('12:00','13:00'),('13:00','14:00'),('14:00','15:00'),('15:00','16:00'),('16:00','17:00')]
        with connect() as db:
            rooms = db.execute('SELECT * FROM rooms WHERE capacity >= ? ORDER BY capacity,code', (capacity,)).fetchall()
            result = []
            for row in rooms:
                room = dict(row)
                if any(not room[item] for item in equipment):
                    continue
                bookings = db.execute("SELECT start_time,end_time FROM bookings WHERE room_id=? AND booking_date=? AND status='active'", (row['id'], day)).fetchall()
                available_slots = [f'{slot_start}-{slot_end}' for slot_start,slot_end in slots if not any(b['start_time'] < slot_end and b['end_time'] > slot_start for b in bookings)]
                occupied = bool(start and end) and any(b['start_time'] < end and b['end_time'] > start for b in bookings)
                if not occupied:
                    room['available_slots'] = available_slots
                    result.append(room)
        return response(start_response, 200, result)
    if method == 'GET' and path == '/api/bookings':
        sql = "SELECT b.*,r.code FROM bookings b JOIN rooms r ON r.id=b.room_id WHERE b.status='active'"
        args = []
        if value('role') != 'admin':
            sql += ' AND b.student=?'; args.append('Stephen Curry')
        if value('date'):
            sql += ' AND b.booking_date=?'; args.append(value('date'))
        if value('room'):
            sql += ' AND r.code=?'; args.append(value('room'))
        sql += ' ORDER BY b.booking_date,b.start_time'
        with connect() as db:
            return response(start_response, 200, [booking_dict(r) for r in db.execute(sql, args).fetchall()])
    if method == 'POST' and path == '/api/bookings':
        try:
            length = min(int(environ.get('CONTENT_LENGTH') or 0), 10000)
            payload = json.loads(environ['wsgi.input'].read(length) or b'{}')
            room_code = str(payload.get('room', '')).strip()
            day = str(payload.get('date', '')).strip()
            start, end = str(payload.get('start', '')).strip(), str(payload.get('end', '')).strip()
            purpose = str(payload.get('purpose', '')).strip()[:120]
            date.fromisoformat(day)
            if datetime.strptime(start, '%H:%M') >= datetime.strptime(end, '%H:%M'):
                raise ValueError
        except (ValueError, TypeError, KeyError, json.JSONDecodeError):
            return response(start_response, 400, {'error':'Enter a valid date and an end time later than the start time.'})
        if len(purpose) < 3:
            return response(start_response, 400, {'error':'Add a purpose of at least 3 characters.'})
        with connect() as db:
            room = db.execute('SELECT id FROM rooms WHERE code=?', (room_code,)).fetchone()
            if not room:
                return response(start_response, 400, {'error':'Choose an available room.'})
            overlap = db.execute('''SELECT 1 FROM bookings WHERE room_id=? AND booking_date=?
                AND status='active' AND start_time < ? AND end_time > ?''',
                (room['id'], day, end, start)).fetchone()
            if overlap:
                return response(start_response, 409, {'error':'This room has an overlapping booking. Choose another time or room.'})
            cur = db.execute('INSERT INTO bookings(room_id,student,booking_date,start_time,end_time,purpose) VALUES(?,?,?,?,?,?)', (room['id'], 'Stephen Curry', day, start, end, purpose))
            row = db.execute('SELECT b.*,r.code FROM bookings b JOIN rooms r ON r.id=b.room_id WHERE b.id=?', (cur.lastrowid,)).fetchone()
            return response(start_response, 201, booking_dict(row))
    match = re.fullmatch(r'/api/bookings/(\d+)', path)
    if method == 'DELETE' and match:
        booking_id = int(match.group(1))
        with connect() as db:
            row = db.execute("SELECT * FROM bookings WHERE id=? AND status='active'", (booking_id,)).fetchone()
            if not row:
                return response(start_response, 404, {'error':'Booking not found or already cancelled.'})
            if value('role') != 'admin' and row['student'] != 'Stephen Curry':
                return response(start_response, 403, {'error':'Students can cancel only their own bookings.'})
            db.execute("UPDATE bookings SET status='cancelled' WHERE id=?", (booking_id,))
            return response(start_response, 200, {'ok':True})
    return response(start_response, 404, {'error':'Not found.'})


if __name__ == '__main__':
    init_db()
    host = os.environ.get('HOST', '127.0.0.1')
    port = int(os.environ.get('PORT', '5000'))
    print(f'CampusRooms listening on http://{host}:{port}')
    make_server(host, port, application).serve_forever()
