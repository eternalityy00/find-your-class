# Find Your Class

**Project:** Find Your Class  
**Author:** Dias Mussin  
**Group:** IIoT 2626  
**Live website:** <https://find-your-class-dias.onrender.com/>  
**Public source repository:** <https://github.com/eternalityy00/find-your-class>

Find Your Class is a responsive university room-booking prototype. A student can filter eight fictional study rooms by date, time, capacity, and equipment, reserve a room, see personal bookings, and cancel them. The administrator demo role can review and cancel every active booking. The interface defaults to English and can be switched to Kazakh, French, or Chinese.

## Run locally

1. Install Python 3.10 or newer.
2. From this directory, run `python app.py`.
3. Open `http://127.0.0.1:5000`.

The app creates `instance/rooms.db` and seeds the database on first run. Set `ROOM_BOOKING_DB` to choose another SQLite file. The default demo student is Stephen Curry. Use the role selector to switch to the administrator view. Use “Language & colors” to choose English, Kazakh, French, or Chinese and customize six colors. Preferences stay in the browser on this device. There are no real accounts or passwords.

## Architecture

![Find Your Class architecture](architecture.svg)

The browser sends room searches, booking requests, and cancellation requests to the Python HTTP API. The server validates requests and reads or writes SQLite records. The browser renders API responses. The administrator selector is a demonstration control, not authentication or authorization suitable for a public production service.

## Data model

`rooms(id, code, capacity, projector, computers, whiteboard)` stores the room inventory. `bookings(id, room_id, student, booking_date, start_time, end_time, purpose, status, created_at)` stores reservations. `room_id` references `rooms.id`. An index on date, room, and status speeds overlap checks. A reservation conflicts when `existing.start_time < requested.end_time` and `existing.end_time > requested.start_time`.

## Publish

The project includes a `Procfile` and `render.yaml` for a small demonstration. Before publishing, push this folder to a Git repository and connect that repository to Render or another Python web host. Set the start command to `python app.py`, bind to `0.0.0.0`, enable HTTPS/TLS at the host, and set `FORCE_HTTPS=1`. The app redirects HTTP requests to HTTPS when the hosting proxy supplies `X-Forwarded-Proto: http` and sends HSTS on HTTPS requests. Open the resulting public URL in a private browser window and on a phone.

**Data persistence caveat:** SQLite uses the host's local filesystem. The current free Render instance has an ephemeral filesystem, so bookings can reset to the seeded examples after a restart or sleep period. For durable public use, change the database to a managed persistent database, add migrations and backups, and replace the demo role selector with real authentication and server-side role checks.

## Search indexing

The live page includes a search description, canonical URL, `robots.txt`, and `sitemap.xml`. Submit `https://find-your-class-dias.onrender.com/` and the sitemap in Google Search Console to request indexing. Google controls when a new page appears in results; publication does not guarantee next-day indexing. Share the direct HTTPS link with the instructor while indexing is pending.

## Implemented functions

- Responsive home, room search, personal bookings, and administrator views.
- Separate language and theme dialog with English, Kazakh, French, and Chinese translations and six persistent user-controlled colors.
- Search by date, time, minimum capacity, and projector/computer/whiteboard.
- SQLite persistence, eight fictional rooms (C1, C2, C3, 101, 150, 200, 250, and 300), and four fictional sample bookings. Stephen Curry is the demo student.
- Reservation validation for date, time order, purpose length, and room overlap.
- Student cancellation of their own reservations and admin cancellation of any active reservation in demo mode.
- Loading, empty, error, confirmation, and success states.
- Basic response security headers and parameterized SQL queries.

## Prototype limits

The role selector is not secure authentication. The demo student identity is fixed. A public deployment, repository, usability sessions, accessibility audit with users, long-term database backup, and operational monitoring still need to be supplied or completed. The sample data are fictional. Color choices are not automatically blocked when they produce low contrast; the settings dialog displays a warning when the selected text and page-background colors fall below a 4.5:1 contrast ratio.

## Project files

- `app.py` — HTTP API and SQLite schema/seed logic.
- `templates/index.html` — application interface.
- `static/app.js` — search, booking, cancellation, and view behavior.
- `static/styles.css` — responsive visual design.
- `tests/test_api.py` — automated API checks.
- `architecture.svg` — system architecture diagram.
- `links.txt` — publication and repository link fields.
