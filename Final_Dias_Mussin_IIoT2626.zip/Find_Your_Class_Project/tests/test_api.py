import io
import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from wsgiref.util import setup_testing_defaults

import app as booking_app


class RoomBookingApiTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.db_path = Path(self.temp.name) / 'test.sqlite'
        self.path_patch = patch.object(booking_app, 'DB_PATH', self.db_path)
        self.path_patch.start()
        booking_app.init_db()
        self.client = self.request
        self.day = '2030-05-16'

    def tearDown(self):
        self.path_patch.stop()
        self.temp.cleanup()

    def payload(self, **changes):
        data = {'room':'C1','date':self.day,'start':'10:00','end':'11:00','purpose':'Study group'}
        data.update(changes)
        return data

    def request(self, method, path, json_body=None, extra=None):
        environ = {}
        setup_testing_defaults(environ)
        if '?' in path:
            environ['PATH_INFO'], environ['QUERY_STRING'] = path.split('?', 1)
        else:
            environ['PATH_INFO'] = path
        environ['REQUEST_METHOD'] = method
        body = json.dumps(json_body).encode() if json_body is not None else b''
        environ['CONTENT_LENGTH'] = str(len(body))
        environ['wsgi.input'] = io.BytesIO(body)
        environ.update(extra or {})
        captured = {}
        def start_response(status, headers, exc_info=None):
            captured['status'] = int(status.split()[0])
            captured['headers'] = dict(headers)
        response_body = b''.join(booking_app.application(environ, start_response))
        try:
            data = json.loads(response_body)
        except (ValueError, UnicodeDecodeError):
            data = response_body.decode('utf-8')
        class Result:
            pass
        result = Result()
        result.status_code = captured['status']
        result.headers = captured['headers']
        result.json = data
        return result

    def test_01_health_endpoint(self):
        response = self.client('GET', '/api/health')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json['status'], 'ok')

    def test_02_seed_has_at_least_six_rooms(self):
        codes = {room['code'] for room in self.client('GET', '/api/rooms').json}
        self.assertGreaterEqual(len(codes), 6)
        self.assertTrue({'C1', 'C2', 'C3'} <= codes)
        self.assertTrue({'101', '150', '200', '250', '300'} <= codes)

    def test_03_capacity_filter(self):
        rooms = self.client('GET', '/api/rooms?capacity=30').json
        self.assertTrue(rooms)
        self.assertTrue(all(room['capacity'] >= 30 for room in rooms))

    def test_04_equipment_filter(self):
        rooms = self.client('GET', '/api/rooms?computers=true&whiteboard=true').json
        self.assertTrue(rooms)
        self.assertTrue(all(room['computers'] and room['whiteboard'] for room in rooms))

    def test_05_booking_succeeds_and_returns_room(self):
        response = self.client('POST', '/api/bookings', self.payload())
        self.assertEqual(response.status_code, 201)
        self.assertEqual(response.json['room'], 'C1')

    def test_06_end_time_must_follow_start_time(self):
        response = self.client('POST', '/api/bookings', self.payload(start='12:00', end='11:00'))
        self.assertEqual(response.status_code, 400)

    def test_07_purpose_is_required(self):
        response = self.client('POST', '/api/bookings', self.payload(purpose=''))
        self.assertEqual(response.status_code, 400)

    def test_08_overlapping_booking_is_rejected(self):
        self.assertEqual(self.client('POST', '/api/bookings', self.payload()).status_code, 201)
        response = self.client('POST', '/api/bookings', self.payload(start='10:30', end='11:30'))
        self.assertEqual(response.status_code, 409)

    def test_09_back_to_back_booking_is_allowed(self):
        self.assertEqual(self.client('POST', '/api/bookings', self.payload()).status_code, 201)
        response = self.client('POST', '/api/bookings', self.payload(start='11:00', end='12:00'))
        self.assertEqual(response.status_code, 201)

    def test_10_student_list_contains_only_demo_students_bookings(self):
        self.client('POST', '/api/bookings', self.payload())
        with booking_app.connect() as db:
            room_id = db.execute("SELECT id FROM rooms WHERE code='C1'").fetchone()[0]
            db.execute("INSERT INTO bookings(room_id,student,booking_date,start_time,end_time,purpose) VALUES(?,'Taylor Reed',?,'13:00','14:00','Study')", (room_id, self.day))
        student = self.client('GET', f'/api/bookings?role=student&date={self.day}').json
        admin = self.client('GET', f'/api/bookings?role=admin&date={self.day}').json
        self.assertEqual(len(student), 1)
        self.assertEqual(len(admin), 2)

    def test_11_student_cannot_cancel_another_students_booking(self):
        with booking_app.connect() as db:
            room_id = db.execute("SELECT id FROM rooms WHERE code='C1'").fetchone()[0]
            cur = db.execute("INSERT INTO bookings(room_id,student,booking_date,start_time,end_time,purpose) VALUES(?,'Taylor Reed',?,'13:00','14:00','Study')", (room_id, self.day))
            booking_id = cur.lastrowid
        self.assertEqual(self.client('DELETE', f'/api/bookings/{booking_id}?role=student').status_code, 403)

    def test_12_admin_can_cancel_a_booking(self):
        created = self.client('POST', '/api/bookings', self.payload()).json
        self.assertEqual(self.client('DELETE', f"/api/bookings/{created['id']}?role=admin").status_code, 200)

    def test_13_security_headers_are_present(self):
        response = self.client('GET', '/')
        self.assertEqual(response.headers.get('X-Content-Type-Options'), 'nosniff')
        self.assertIn('frame-ancestors', response.headers.get('Content-Security-Policy', ''))

    def test_14_open_slots_reflect_active_bookings(self):
        today = __import__('datetime').date.today().isoformat()
        rooms = self.client('GET', f'/api/rooms?date={today}').json
        room = next(room for room in rooms if room['code'] == 'C1')
        self.assertNotIn('15:00-16:00', room['available_slots'])

    def test_15_http_is_redirected_and_https_gets_hsts(self):
        with patch.dict(os.environ, {'FORCE_HTTPS':'1'}):
            redirected = self.client('GET', '/', extra={'HTTP_HOST':'rooms.example','HTTP_X_FORWARDED_PROTO':'http'})
            secure = self.client('GET', '/api/health', extra={'HTTP_HOST':'rooms.example','HTTP_X_FORWARDED_PROTO':'https'})
        self.assertEqual(redirected.status_code, 308)
        self.assertEqual(redirected.headers.get('Location'), 'https://rooms.example/')
        self.assertIn('max-age=31536000', secure.headers.get('Strict-Transport-Security',''))


if __name__ == '__main__':
    unittest.main(verbosity=2)
