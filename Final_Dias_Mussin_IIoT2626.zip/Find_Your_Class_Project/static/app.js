const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];
const languageNames = {en:'English',kk:'Қазақша',fr:'Français',zh:'中文'};
const dictionaries = {
  en:{nav_home:'Home',nav_find:'Find a room',nav_bookings:'My bookings',nav_admin:'Admin',settings_button:'Language & colors',demo_role:'Demo role',role_student:'Student',role_admin:'Administrator',hero_eyebrow:'UNIVERSITY STUDY SPACES',hero_title_line1:'Find your place',hero_title_line2:'to',hero_title_em:'focus.',hero_text:'Book the right room for your next study session, project meeting, or workshop. Check availability in seconds.',find_a_room:'Find a room',my_bookings:'My bookings',hero_note:'A simple demo for better campus spaces',art_caption:'Your next study space',feature1_title:'Search by what matters',feature1_text:'Choose a time, room size, and the equipment you need.',feature2_title:'Book in a few clicks',feature2_text:'See available rooms and reserve a slot without overlap.',feature3_title:'Stay in control',feature3_text:'View your reservations and cancel when plans change.',space_finder:'SPACE FINDER',search_intro:'Set your requirements and we’ll show you rooms that fit.',date:'Date',start_time:'Start time',end_time:'End time',minimum_capacity:'Minimum capacity',equipment:'Equipment',projector:'Projector',computers:'Computers',whiteboard:'Whiteboard',search_rooms:'Search rooms',available_rooms:'Available rooms',your_space:'YOUR SPACE',manage_bookings:'Manage your upcoming room reservations.',demo_admin:'DEMO ADMINISTRATION',all_bookings:'All bookings',review_bookings:'Review and manage room reservations.',admin_badge:'Prototype admin view',filter_date:'Filter by date',filter_room:'Filter by room',all_rooms:'All rooms',clear_filters:'Clear filters',footer_text:'University room booking · Learning prototype',demo_student:'Demo student:',new_reservation:'NEW RESERVATION',book_room:'Book this room',purpose:'Purpose',confirm_booking:'Confirm booking',cancel:'Cancel',personalize:'PERSONALIZE',settings_title:'Language and colors',choose_language:'Choose a language',custom_colors:'Custom colors',color_help:'Choose each site color. Changes preview immediately and stay saved on this device.',color_primary:'Primary',color_accent:'Accent',color_background:'Background',color_surface:'Cards and panels',color_text:'Text',color_borders:'Borders',contrast_warning:'These colors may reduce text contrast.',reset_colors:'Reset colors',done:'Done',no_rooms:'No rooms match these filters',no_rooms_help:'Try a different time, capacity, or equipment selection.',rooms_load_error:'Rooms could not be loaded',server_running:'Check that the demo server is running, then try again.',room_available:'Study room · Available for your selected time',open_slots:'Open slots',book_button:'Book this room',capacity:'Up to',room_count_one:'room',room_count_many:'rooms',checking:'Checking availability…',loading_rooms:'Loading rooms…',booking_success:'Room {room} booked successfully',student_role_on:'Student demo role enabled',admin_role_on:'Administrator demo role enabled',switch_student:'Switch to Student to create a demo booking',no_admin_bookings:'No bookings found',adjust_filters:'Try adjusting the filters.',no_my_bookings:'No bookings yet',find_and_book:'Find a room and your reservation will appear here.',booking_room:'Room reservation',active:'Active',cancel_booking:'Cancel',cancel_any:'Cancel booking',confirm_cancel_student:'Cancel your booking?',confirm_cancel_admin:'Cancel this booking for everyone?',cancelled:'Booking cancelled',cancel_error:'This booking could not be cancelled',bookings_load_error:'Bookings could not be loaded',valid_time:'Enter a valid date and an end time later than the start time.',purpose_error:'Add a purpose of at least 3 characters.',room_error:'Choose an available room.',overlap_error:'This room has an overlapping booking. Choose another time or room.',save_error:'The server could not save your booking. Please try again.',empty_basic:'Basic setup',study_day:'Study session',close:'Close',illustration:'Illustration of a campus study room',contrast_warning:'These colors may reduce text contrast.'},
  kk:{nav_home:'Басты бет',nav_find:'Аудитория табу',nav_bookings:'Брондауларым',nav_admin:'Әкімші',settings_button:'Тіл және түстер',demo_role:'Демо рөлі',role_student:'Студент',role_admin:'Әкімші',hero_eyebrow:'УНИВЕРСИТЕТ АУДИТОРИЯЛАРЫ',hero_title_line1:'Өзіңе орын тап',hero_title_line2:'және',hero_title_em:'оқы.',hero_text:'Сабаққа, жоба кездесуіне немесе топтық жұмысқа лайық аудиторияны брондаңыз. Бос уақытты тез тексеріңіз.',find_a_room:'Аудитория табу',my_bookings:'Брондауларым',hero_note:'Университет кеңістігіне арналған демо',art_caption:'Келесі оқу кеңістігіңіз',feature1_title:'Қажеттісін таңдаңыз',feature1_text:'Күнді, уақытты, сыйымдылықты және жабдықты таңдаңыз.',feature2_title:'Бірнеше қадамда брондаңыз',feature2_text:'Бос аудиторияны көріп, уақытын брондаңыз.',feature3_title:'Брондауды басқарыңыз',feature3_text:'Брондауларды көріп, қажет болса болдырмаңыз.',space_finder:'АУДИТОРИЯ ІЗДЕУ',search_intro:'Шарттарды таңдаңыз — сәйкес аудиторияларды көрсетеміз.',date:'Күні',start_time:'Басталу уақыты',end_time:'Аяқталу уақыты',minimum_capacity:'Ең аз сыйымдылық',equipment:'Жабдықтар',projector:'Проектор',computers:'Компьютерлер',whiteboard:'Ақ тақта',search_rooms:'Іздеу',available_rooms:'Бос аудиториялар',your_space:'СІЗДІҢ БРОНДАУЛАР',manage_bookings:'Алдағы аудитория брондауларын басқарыңыз.',demo_admin:'ӘКІМШІ ДЕМОСЫ',all_bookings:'Барлық брондаулар',review_bookings:'Аудитория брондауларын қарау және басқару.',admin_badge:'Әкімші прототипі',filter_date:'Күні бойынша',filter_room:'Аудитория бойынша',all_rooms:'Барлық аудитория',clear_filters:'Сүзгіні тазарту',footer_text:'Аудитория брондау · Оқу прототипі',demo_student:'Демо студенті:',new_reservation:'ЖАҢА БРОНДАУ',book_room:'Аудиторияны брондау',purpose:'Мақсаты',confirm_booking:'Брондауды растау',cancel:'Болдырмау',personalize:'БЕЙІМДЕУ',settings_title:'Тіл және түстер',choose_language:'Тілді таңдаңыз',custom_colors:'Түстерді баптау',color_help:'Сайт түстерін таңдаңыз. Өзгерістер бірден көрінеді және осы құрылғыда сақталады.',color_primary:'Негізгі түс',color_accent:'Қосымша түс',color_background:'Фон',color_surface:'Карточкалар мен панельдер',color_text:'Мәтін',color_borders:'Жиектер',contrast_warning:'Бұл түстер мәтін контрастын төмендетуі мүмкін.',reset_colors:'Түстерді қалпына келтіру',done:'Дайын',no_rooms:'Сәйкес аудитория табылмады',no_rooms_help:'Уақытты, сыйымдылықты немесе жабдықты өзгертіңіз.',rooms_load_error:'Аудиторияларды жүктеу мүмкін болмады',server_running:'Демо серверін тексеріп, қайта көріңіз.',room_available:'Оқу бөлмесі · Таңдалған уақытта бос',open_slots:'Бос уақыттар',book_button:'Брондау',capacity:'Сыйымдылығы',room_count_one:'аудитория',room_count_many:'аудитория',checking:'Бос уақыт тексерілуде…',loading_rooms:'Брондаулар жүктелуде…',booking_success:'{room} аудиториясы брондалды',student_role_on:'Студент демо рөлі қосылды',admin_role_on:'Әкімші демо рөлі қосылды',switch_student:'Брондау үшін Студент рөліне ауысыңыз',no_admin_bookings:'Брондау табылмады',adjust_filters:'Сүзгілерді өзгертіп көріңіз.',no_my_bookings:'Брондау әлі жоқ',find_and_book:'Аудиторияны тауып брондаңыз — брондау осында көрінеді.',booking_room:'Аудитория брондауы',active:'Белсенді',cancel_booking:'Болдырмау',cancel_any:'Брондауды жою',confirm_cancel_student:'Брондауды болдырмау керек пе?',confirm_cancel_admin:'Бұл брондауды барлығына болдырмау керек пе?',cancelled:'Брондау болдырылмады',cancel_error:'Брондауды болдырмау мүмкін болмады',bookings_load_error:'Брондауларды жүктеу мүмкін болмады',valid_time:'Күн мен уақытты дұрыс енгізіңіз. Аяқталу уақыты басталу уақытынан кейін болуы керек.',purpose_error:'Мақсатын кемінде 3 таңбамен жазыңыз.',room_error:'Бос аудиторияны таңдаңыз.',overlap_error:'Бұл аудитория осы уақытта бос емес. Басқа уақытты не аудиторияны таңдаңыз.',save_error:'Брондауды сақтау мүмкін болмады. Қайталап көріңіз.',empty_basic:'Негізгі жабдықтар',study_day:'Оқу',close:'Жабу',illustration:'Университет аудиториясының иллюстрациясы'},
  fr:{nav_home:'Accueil',nav_find:'Trouver une salle',nav_bookings:'Mes réservations',nav_admin:'Admin',settings_button:'Langue et couleurs',demo_role:'Rôle démo',role_student:'Étudiant',role_admin:'Administrateur',hero_eyebrow:'ESPACES D’ÉTUDE UNIVERSITAIRES',hero_title_line1:'Trouvez votre place',hero_title_line2:'pour',hero_title_em:'étudier.',hero_text:'Réservez la salle adaptée à vos révisions, réunions de projet ou ateliers. Vérifiez les disponibilités en quelques secondes.',find_a_room:'Trouver une salle',my_bookings:'Mes réservations',hero_note:'Une démo pour de meilleurs espaces de campus',art_caption:'Votre prochain espace d’étude',feature1_title:'Cherchez selon vos besoins',feature1_text:'Choisissez l’heure, la capacité et les équipements.',feature2_title:'Réservez en quelques clics',feature2_text:'Consultez les salles libres et réservez un créneau.',feature3_title:'Gardez le contrôle',feature3_text:'Consultez vos réservations et annulez-les si besoin.',space_finder:'RECHERCHE DE SALLE',search_intro:'Définissez vos critères et voyez les salles adaptées.',date:'Date',start_time:'Heure de début',end_time:'Heure de fin',minimum_capacity:'Capacité minimale',equipment:'Équipement',projector:'Projecteur',computers:'Ordinateurs',whiteboard:'Tableau blanc',search_rooms:'Rechercher',available_rooms:'Salles disponibles',your_space:'VOTRE ESPACE',manage_bookings:'Gérez vos réservations de salles à venir.',demo_admin:'ADMINISTRATION DÉMO',all_bookings:'Toutes les réservations',review_bookings:'Consultez et gérez les réservations de salles.',admin_badge:'Vue admin prototype',filter_date:'Filtrer par date',filter_room:'Filtrer par salle',all_rooms:'Toutes les salles',clear_filters:'Effacer les filtres',footer_text:'Réservation de salles · Prototype pédagogique',demo_student:'Étudiant démo :',new_reservation:'NOUVELLE RÉSERVATION',book_room:'Réserver cette salle',purpose:'Motif',confirm_booking:'Confirmer la réservation',cancel:'Annuler',personalize:'PERSONNALISER',settings_title:'Langue et couleurs',choose_language:'Choisir une langue',custom_colors:'Couleurs personnalisées',color_help:'Choisissez les couleurs du site. L’aperçu change immédiatement et reste enregistré sur cet appareil.',color_primary:'Principale',color_accent:'Accent',color_background:'Arrière-plan',color_surface:'Cartes et panneaux',color_text:'Texte',color_borders:'Bordures',contrast_warning:'Ces couleurs peuvent réduire le contraste du texte.',reset_colors:'Réinitialiser',done:'Terminé',no_rooms:'Aucune salle ne correspond à ces critères',no_rooms_help:'Essayez une autre heure, capacité ou sélection d’équipements.',rooms_load_error:'Impossible de charger les salles',server_running:'Vérifiez que le serveur de démo fonctionne, puis réessayez.',room_available:'Salle d’étude · Disponible à l’heure choisie',open_slots:'Créneaux libres',book_button:'Réserver cette salle',capacity:'Jusqu’à',room_count_one:'salle',room_count_many:'salles',checking:'Vérification des disponibilités…',loading_rooms:'Chargement des réservations…',booking_success:'Salle {room} réservée',student_role_on:'Rôle étudiant démo activé',admin_role_on:'Rôle administrateur démo activé',switch_student:'Passez en mode Étudiant pour réserver',no_admin_bookings:'Aucune réservation trouvée',adjust_filters:'Modifiez les filtres.',no_my_bookings:'Aucune réservation',find_and_book:'Trouvez une salle; votre réservation apparaîtra ici.',booking_room:'Réservation de salle',active:'Active',cancel_booking:'Annuler',cancel_any:'Annuler la réservation',confirm_cancel_student:'Annuler votre réservation ?',confirm_cancel_admin:'Annuler cette réservation pour tout le monde ?',cancelled:'Réservation annulée',cancel_error:'Impossible d’annuler cette réservation',bookings_load_error:'Impossible de charger les réservations',valid_time:'Saisissez une date et des horaires valides. La fin doit être après le début.',purpose_error:'Saisissez un motif d’au moins 3 caractères.',room_error:'Choisissez une salle disponible.',overlap_error:'Cette salle est déjà réservée à cette heure. Choisissez un autre horaire ou une autre salle.',save_error:'Le serveur n’a pas pu enregistrer la réservation. Réessayez.',empty_basic:'Équipement de base',study_day:'Révision',close:'Fermer',illustration:'Illustration d’une salle d’étude universitaire'},
  zh:{nav_home:'首页',nav_find:'查找教室',nav_bookings:'我的预订',nav_admin:'管理',settings_button:'语言和颜色',demo_role:'演示角色',role_student:'学生',role_admin:'管理员',hero_eyebrow:'大学学习空间',hero_title_line1:'找到适合你的空间',hero_title_line2:'专注',hero_title_em:'学习。',hero_text:'为自习、小组项目或研讨会预订合适的教室。快速查看可用时间。',find_a_room:'查找教室',my_bookings:'我的预订',hero_note:'为校园空间打造的演示项目',art_caption:'你的下一个学习空间',feature1_title:'按需求查找',feature1_text:'选择日期、时间、人数和所需设备。',feature2_title:'几步完成预订',feature2_text:'查看空闲教室并预订时段。',feature3_title:'轻松管理',feature3_text:'查看预订，计划有变时可取消。',space_finder:'教室搜索',search_intro:'设置条件，我们会显示符合要求的教室。',date:'日期',start_time:'开始时间',end_time:'结束时间',minimum_capacity:'最少人数',equipment:'设备',projector:'投影仪',computers:'电脑',whiteboard:'白板',search_rooms:'搜索教室',available_rooms:'可用教室',your_space:'我的空间',manage_bookings:'管理即将到来的教室预订。',demo_admin:'演示管理',all_bookings:'所有预订',review_bookings:'查看并管理教室预订。',admin_badge:'原型管理视图',filter_date:'按日期筛选',filter_room:'按教室筛选',all_rooms:'所有教室',clear_filters:'清除筛选',footer_text:'大学教室预订 · 学习原型',demo_student:'演示学生：',new_reservation:'新建预订',book_room:'预订此教室',purpose:'用途',confirm_booking:'确认预订',cancel:'取消',personalize:'个性化设置',settings_title:'语言和颜色',choose_language:'选择语言',custom_colors:'自定义颜色',color_help:'选择网站各项颜色。更改会立即预览并保存在此设备上。',color_primary:'主色',color_accent:'强调色',color_background:'背景',color_surface:'卡片和面板',color_text:'文字',color_borders:'边框',contrast_warning:'这些颜色可能降低文字对比度。',reset_colors:'重置颜色',done:'完成',no_rooms:'没有符合条件的教室',no_rooms_help:'请尝试更改时间、人数或设备选项。',rooms_load_error:'无法加载教室',server_running:'请检查演示服务器是否运行，然后重试。',room_available:'自习室 · 所选时间可用',open_slots:'空闲时段',book_button:'预订此教室',capacity:'最多',room_count_one:'间教室',room_count_many:'间教室',checking:'正在检查空闲情况…',loading_rooms:'正在加载预订…',booking_success:'已预订教室 {room}',student_role_on:'已启用学生演示角色',admin_role_on:'已启用管理员演示角色',switch_student:'切换到学生角色以创建演示预订',no_admin_bookings:'未找到预订',adjust_filters:'请调整筛选条件。',no_my_bookings:'暂无预订',find_and_book:'查找并预订教室，预订将显示在此处。',booking_room:'教室预订',active:'有效',cancel_booking:'取消',cancel_any:'取消预订',confirm_cancel_student:'要取消此预订吗？',confirm_cancel_admin:'要为所有人取消此预订吗？',cancelled:'预订已取消',cancel_error:'无法取消此预订',bookings_load_error:'无法加载预订',valid_time:'请输入有效日期和时间。结束时间必须晚于开始时间。',purpose_error:'用途至少需要 3 个字符。',room_error:'请选择一间可用教室。',overlap_error:'该教室在此时间已有预订。请选择其他时间或教室。',save_error:'服务器无法保存预订，请重试。',empty_basic:'基础设备',study_day:'学习',close:'关闭',illustration:'大学学习教室插图'}
};
Object.assign(dictionaries.en,{purpose_placeholder:'e.g. Group project meeting',nav_aria:'Main navigation'});
Object.assign(dictionaries.kk,{purpose_placeholder:'Мысалы: топтық жоба кездесуі',nav_aria:'Негізгі навигация'});
Object.assign(dictionaries.fr,{purpose_placeholder:'Ex. réunion de projet en groupe',nav_aria:'Navigation principale'});
Object.assign(dictionaries.zh,{purpose_placeholder:'例如：小组项目讨论',nav_aria:'主导航'});
const colorDefaults = {forest:'#174d40',forest2:'#226655',paper:'#faf9f5',white:'#ffffff',ink:'#18312c',line:'#e3e8e3'};
let lang = localStorage.getItem('fyc_language') || 'en';
function t(key) { return (dictionaries[lang] && dictionaries[lang][key]) || dictionaries.en[key] || key; }
function applyLanguage() {
  document.documentElement.lang = ({en:'en',kk:'kk',fr:'fr',zh:'zh-CN'})[lang] || 'en';
  $$('[data-i18n]').forEach(el => { el.textContent = t(el.dataset.i18n); });
  $$('[data-i18n-placeholder]').forEach(el => { el.placeholder = t(el.dataset.i18nPlaceholder); });
  $$('[data-i18n-aria]').forEach(el => { el.setAttribute('aria-label', t(el.dataset.i18nAria)); });
  $('#language').value = lang;
  $('#results-title').textContent = t('available_rooms');
  $('#settings-dialog').setAttribute('aria-label', t('settings_title'));
  $('#booking-dialog').setAttribute('aria-label', t('book_room'));
  $('[aria-label="Main navigation"], [data-i18n-aria="nav_aria"]')?.setAttribute('aria-label', t('nav_aria'));
  document.title = `${t('find_a_room')} | Find Your Class`;
}
function applyTheme(theme) {
  const root = document.documentElement;
  Object.entries(colorDefaults).forEach(([name, fallback]) => {
    const value = theme?.[name] || fallback;
    root.style.setProperty(`--${name}`, value);
    const input = $(`[data-color="${name}"]`);
    if (input) input.value = value;
  });
  const colors = Object.fromEntries(Object.keys(colorDefaults).map(name => [name, theme?.[name] || colorDefaults[name]]));
  localStorage.setItem('fyc_theme', JSON.stringify(colors));
  const ratio = contrastRatio(colors.ink, colors.paper);
  $('#contrast-warning').classList.toggle('hidden', ratio >= 4.5);
}
function contrastRatio(a, b) {
  const luminance = color => {
    const rgb = color.slice(1).match(/.{2}/g).map(v => parseInt(v, 16) / 255).map(v => v <= .04045 ? v / 12.92 : ((v + .055) / 1.055) ** 2);
    return .2126 * rgb[0] + .7152 * rgb[1] + .0722 * rgb[2];
  };
  const vals = [luminance(a), luminance(b)].sort((x, y) => y - x);
  return (vals[0] + .05) / (vals[1] + .05);
}
function toast(message) {
  const el = $('#toast'); el.textContent = message; el.classList.add('show');
  setTimeout(() => el.classList.remove('show'), 2600);
}
function selectedView(view) {
  $$('.view').forEach(el => el.classList.toggle('hidden', el.id !== `view-${view}`));
  $$('.nav-link').forEach(el => el.classList.toggle('active', el.dataset.view === view));
  if (view === 'find') searchRooms();
  if (view === 'bookings') loadBookings(false);
  if (view === 'admin') loadBookings(true);
  window.scrollTo({top: 0, behavior: 'smooth'});
}
$$('[data-view]').forEach(el => el.addEventListener('click', () => selectedView(el.dataset.view)));
const roleSelect = $('#role');
roleSelect.addEventListener('change', () => {
  const admin = roleSelect.value === 'admin';
  $('.admin-link').classList.toggle('hidden', !admin);
  if (admin && !$('#view-admin').classList.contains('hidden')) loadBookings(true);
  if (!admin && !$('#view-admin').classList.contains('hidden')) selectedView('home');
  toast(t(admin ? 'admin_role_on' : 'student_role_on'));
});
$('#open-settings').addEventListener('click', () => $('#settings-dialog').showModal());
$('#settings-close').addEventListener('click', () => $('#settings-dialog').close());
$('#settings-done').addEventListener('click', () => $('#settings-dialog').close());
$('#language').addEventListener('change', e => { lang = e.target.value; localStorage.setItem('fyc_language', lang); applyLanguage(); });
$$('[data-color]').forEach(input => input.addEventListener('input', () => {
  const theme = JSON.parse(localStorage.getItem('fyc_theme') || '{}');
  theme[input.dataset.color] = input.value; applyTheme(theme);
}));
$('#reset-appearance').addEventListener('click', () => applyTheme(colorDefaults));

function searchParams() {
  const p = new URLSearchParams({date: $('#search-date').value, start: $('#search-start').value, end: $('#search-end').value, capacity: $('#search-capacity').value || '1'});
  $$('input[name="equipment"]:checked').forEach(el => p.set(el.value, 'true'));
  return p;
}
function equipmentNames(room) {
  return [['projector', room.projector], ['computers', room.computers], ['whiteboard', room.whiteboard]].filter(([, yes]) => yes).map(([name]) => t(name));
}
function escapeHtml(text) { return String(text).replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch])); }
function roomCard(room) {
  const equipment = equipmentNames(room).map(x => `<span>${escapeHtml(x)}</span>`).join('') || `<span>${t('empty_basic')}</span>`;
  const slots = room.available_slots.slice(0, 5).map(escapeHtml).join(' · ') || '—';
  return `<article class="room-card"><div class="room-top"><span class="room-code">${escapeHtml(room.code)}</span><span class="room-capacity">${t('capacity')} ${room.capacity}</span></div><p class="room-details">${t('room_available')}</p><div class="equipment">${equipment}</div><p class="slot-list"><strong>${t('open_slots')}:</strong> ${slots}</p><button class="button primary book-room" data-room="${escapeHtml(room.code)}">${t('book_button')} <span aria-hidden="true">→</span></button></article>`;
}
async function searchRooms(event) {
  if (event) event.preventDefault();
  const wrap = $('#room-results'); wrap.innerHTML = `<div class="loading">${t('checking')}</div>`;
  try {
    const res = await fetch(`/api/rooms?${searchParams()}`), rooms = await res.json();
    $('#results-count').textContent = `${rooms.length} ${t(rooms.length === 1 ? 'room_count_one' : 'room_count_many')}`;
    wrap.innerHTML = rooms.length ? rooms.map(roomCard).join('') : `<div class="empty-state"><h3>${t('no_rooms')}</h3><p>${t('no_rooms_help')}</p></div>`;
    $$('.book-room').forEach(btn => btn.addEventListener('click', () => openBooking(btn.dataset.room)));
  } catch { wrap.innerHTML = `<div class="empty-state"><h3>${t('rooms_load_error')}</h3><p>${t('server_running')}</p></div>`; }
}
$('#search-form').addEventListener('submit', searchRooms);
$('#search-start').addEventListener('change', searchRooms);
$('#search-end').addEventListener('change', searchRooms);

function openBooking(room) {
  if (roleSelect.value !== 'student') { toast(t('switch_student')); return; }
  $('#booking-room').value = room;
  $('#dialog-room-name').textContent = `${room} · ${$('#search-date').value} · ${$('#search-start').value}–${$('#search-end').value}`;
  $('#booking-date').value = $('#search-date').value;
  $('#booking-start').value = $('#search-start').value;
  $('#booking-end').value = $('#search-end').value;
  $('#form-error').classList.add('hidden'); $('#booking-dialog').showModal(); $('#booking-purpose').focus();
}
$('.dialog-close').addEventListener('click', () => $('#booking-dialog').close());
$('.dialog-cancel').addEventListener('click', () => $('#booking-dialog').close());
$('#booking-form').addEventListener('submit', async event => {
  event.preventDefault();
  const data = {room:$('#booking-room').value,date:$('#booking-date').value,start:$('#booking-start').value,end:$('#booking-end').value,purpose:$('#booking-purpose').value.trim()};
  const err = $('#form-error');
  try {
    const res = await fetch('/api/bookings', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)}), body = await res.json();
    if (!res.ok) { err.textContent = t(res.status === 409 ? 'overlap_error' : body.error?.includes('purpose') ? 'purpose_error' : 'valid_time'); err.classList.remove('hidden'); return; }
    $('#booking-dialog').close(); $('#booking-form').reset(); toast(t('booking_success').replace('{room}', body.room)); searchRooms();
  } catch { err.textContent = t('save_error'); err.classList.remove('hidden'); }
});

function bookingCard(b, admin) {
  const d = new Date(`${b.booking_date}T00:00:00`), locale = ({en:'en-US',kk:'kk-KZ',fr:'fr-FR',zh:'zh-CN'})[lang];
  const dateLabel = d.toLocaleDateString(locale, {month:'short',day:'numeric'});
  return `<article class="booking-card"><div class="booking-date"><strong>${dateLabel}</strong><span>${d.toLocaleDateString(locale,{weekday:'long'})}</span></div><div class="booking-info"><h3>${escapeHtml(b.room)} <span class="booking-meta">· ${escapeHtml(b.start_time)}–${escapeHtml(b.end_time)}</span></h3><p>${admin ? `${escapeHtml(b.student)} · ` : ''}${t('booking_room')}</p><p class="purpose">${escapeHtml(b.purpose)}</p></div><div class="booking-actions">${admin ? `<span class="booking-meta">${t('active')}</span>` : ''}<button class="cancel-button" data-id="${b.id}">${t(admin ? 'cancel_any' : 'cancel_booking')}</button></div></article>`;
}
async function loadBookings(admin) {
  const wrap = $(admin ? '#admin-bookings' : '#my-bookings'); wrap.innerHTML = `<div class="loading">${t('loading_rooms')}</div>`;
  const params = new URLSearchParams({role:admin?'admin':'student'});
  if (admin && $('#admin-date').value) params.set('date', $('#admin-date').value);
  if (admin && $('#admin-room').value) params.set('room', $('#admin-room').value);
  try {
    const res = await fetch(`/api/bookings?${params}`), bookings = await res.json();
    if (admin) {
      const rooms = await (await fetch('/api/rooms')).json(), select = $('#admin-room'), current = select.value;
      select.innerHTML = `<option value="">${t('all_rooms')}</option>` + rooms.map(r => `<option value="${escapeHtml(r.code)}">${escapeHtml(r.code)}</option>`).join(''); select.value = current;
    }
    wrap.innerHTML = bookings.length ? bookings.map(b => bookingCard(b,admin)).join('') : `<div class="empty-state"><h3>${t(admin?'no_admin_bookings':'no_my_bookings')}</h3><p>${t(admin?'adjust_filters':'find_and_book')}</p>${admin?'':`<button class="button primary" data-view="find">${t('find_a_room')}</button>`}</div>`;
    wrap.querySelectorAll('[data-view="find"]').forEach(btn => btn.addEventListener('click', () => selectedView('find')));
    wrap.querySelectorAll('.cancel-button').forEach(btn => btn.addEventListener('click', async () => {
      if (!confirm(t(admin?'confirm_cancel_admin':'confirm_cancel_student'))) return;
      const result = await fetch(`/api/bookings/${btn.dataset.id}?role=${admin?'admin':'student'}`,{method:'DELETE'});
      if (result.ok) { toast(t('cancelled')); loadBookings(admin); if (!admin) searchRooms(); } else toast(t('cancel_error'));
    }));
  } catch { wrap.innerHTML = `<div class="empty-state"><h3>${t('bookings_load_error')}</h3></div>`; }
}
$('#admin-date').addEventListener('change', () => loadBookings(true));
$('#admin-room').addEventListener('change', () => loadBookings(true));
$('#clear-admin').addEventListener('click', () => { $('#admin-date').value=''; $('#admin-room').value=''; loadBookings(true); });

const today = new Date(), localDate = new Date(today.getTime() - today.getTimezoneOffset()*60000).toISOString().slice(0,10);
$('#search-date').value = localDate; $('#booking-date').value = localDate;
try { applyTheme(JSON.parse(localStorage.getItem('fyc_theme') || '{}')); } catch { applyTheme(colorDefaults); }
applyLanguage(); searchRooms();
